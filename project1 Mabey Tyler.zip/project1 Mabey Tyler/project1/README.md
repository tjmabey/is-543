Founders app
Tyler Mabey

This project was challenging for me. I spent close to 15 hours working on it in total. I wanted to spend more time on improving the UI but focused on making things functional first. One of the hardest parts initially was learning how to pass data between view controllers. I also spent a lot of time trying to improve the user interface but kept running out of time.
